/* eslint-disable react-hooks/rules-of-hooks */
import React, { useState, useEffect } from 'react'
import style from './Steps.module.scss'
import { Button } from 'antd'
import cn from 'classnames'
interface IProps {
  setp: Isetp[]//你的tab栏信息
  skip?: boolean,//是否可以继续下一步，页面是否填写完毕
  start: number,//默认开始的步数
  callBack: (indexStep: number) => void//下一步的的回调可通过回调判断渲染的页面
  finishCallback?: (any?: any) => void//成功的回调
}
interface Isetp {
  title?: string,//标题
  buttonMsg: IbtnMsg,//button按钮的对象
}
interface IbtnMsg {
  pre?: string,//上步按钮
  next?: string,//下一步按钮
  finsh?: string//完成的按钮
  customButton?: IbuttonMethod[]
}
interface IbuttonMethod {
  title: string,//按钮名字
  buttonCallback: Function//执行的回调
}
const index: React.FC<IProps> = (props) => {
  const { skip, callBack, finishCallback, start } = props
  const [menu, setMenu] = useState(props.setp)
  const [num, setNum] = useState(start)
  useEffect(() => {
    callBack(num)
  }, [num])

  return (
    <div className={style.box}>
      <div className={style.top}>
        {
          menu.map((item, index) => {
            return <span key={index} className={cn({
              [style.borderLeft]: index === 0,
              [style.borderRight]: index === menu.length - 1,
              [style.active]: index === num,
              [style.finish]: (skip === true && index < num) || index < num
            })} onClick={() => {
              if (skip || index < num) {
                setNum(index)
              }
            }}><b>{index + 1}</b>{item.title}<i className={style.span}></i></span>
          })
        }
      </div>
      <div className={style.content}>
        <div className={style.main}>
          {
            props.children
          }
        </div>
      </div>
      <div className={style.footer}>
        {
          num > 0 ? <button onClick={() => {
            if (num > 0) {
              setNum(num - 1)
            }
          }}>{
              menu[num].buttonMsg.pre !== undefined ? menu[num].buttonMsg.pre : '上一步'
            }</button> : null
        }
        {
          menu[num].buttonMsg && menu[num].buttonMsg.customButton && menu[num].buttonMsg.customButton.map((item, i) => {
            return <button key={i} onClick={() => { item.buttonCallback && item.buttonCallback() }}>{item.title}</button>
          })
        }
        {
          num < menu.length - 1 ? <button onClick={() => {
            if (num < menu.length - 1 && skip) {
              setNum(num + 1)
            }
          }}>
            {menu[num].buttonMsg.next !== undefined ? menu[num].buttonMsg.next : '下一步'}
          </button> : <button onClick={() => {
            if (num === menu.length - 1 && skip) {
              finishCallback && finishCallback()
            }
          }}>
            {menu[num].buttonMsg.finsh !== undefined ? menu[num].buttonMsg.finsh : '完成'}
          </button>
        }
      </div>
    </div>
  )
}

export default index
